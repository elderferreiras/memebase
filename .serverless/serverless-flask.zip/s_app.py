import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='elderpattenferreira',
    application_name='memebase',
    app_uid='4mccPRLHnCg4B9G3Mc',
    org_uid='SHhTjghC4g4xV9dzp2',
    deployment_uid='9f916bd6-d024-4a2c-871c-07dc6527560f',
    service_name='serverless-flask',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.4.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'serverless-flask-dev-app', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
